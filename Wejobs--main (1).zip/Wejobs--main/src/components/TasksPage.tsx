import React, { useState, useMemo, useEffect } from 'react';
import { Task, MainCategory, User } from '../types';
import { TaskDetailPage } from './TaskDetailPage';
import {
  Search,
  Filter,
  SlidersHorizontal,
  Clock,
  DollarSign,
  Star,
  Users,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
  ChevronLeft,
  ChevronsLeft,
  ChevronsRight,
  ArrowUpDown,
  BookOpen,
  Feather,
  Edit3,
  FileCheck,
  Languages,
  Headphones,
  Tag,
  RefreshCw,
  X,
} from 'lucide-react';

interface TasksPageProps {
  tasks: Task[];
  stats: {
    totalTasks: number;
    fullTasks: number;
    availableTasks: number;
  };
  user: User | null;
  selectedCategory?: string;
  onClaimTask: (taskId: string) => Promise<boolean>;
  onOpenLogin: () => void;
  onRefreshTasks?: () => void;
}

export const TasksPage: React.FC<TasksPageProps> = ({
  tasks,
  stats,
  user,
  selectedCategory = 'all',
  onClaimTask,
  onOpenLogin,
  onRefreshTasks,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>(selectedCategory);
  const [activeSubtype, setActiveSubtype] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'available' | 'full'>('available');
  const [sortBy, setSortBy] = useState<string>('newest');
  const [minPayment, setMinPayment] = useState<number>(0);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(24);
  const [jumpPageInput, setJumpPageInput] = useState<string>('');

  // Synchronize when selectedCategory prop changes from external navigation
  useEffect(() => {
    if (selectedCategory && selectedCategory !== activeCategory) {
      setActiveCategory(selectedCategory);
      setActiveSubtype('all');
      setCurrentPage(1);
    }
  }, [selectedCategory]);

  // Reset page when any filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [activeCategory, activeSubtype, searchQuery, statusFilter, sortBy, minPayment]);

  const categories: { label: string; value: string; count: number }[] = [
    { label: 'Semua Disiplin', value: 'all', count: tasks.length || stats.totalTasks },
    { label: 'Writing', value: 'Writing', count: tasks.filter((t) => t.category.toLowerCase() === 'writing').length },
    { label: 'Creative Writing', value: 'Creative Writing', count: tasks.filter((t) => t.category.toLowerCase() === 'creative writing').length },
    { label: 'Editing', value: 'Editing', count: tasks.filter((t) => t.category.toLowerCase() === 'editing').length },
    { label: 'Research & Writing', value: 'Research & Writing', count: tasks.filter((t) => t.category.toLowerCase() === 'research & writing').length },
    { label: 'Translation', value: 'Translation', count: tasks.filter((t) => t.category.toLowerCase() === 'translation').length },
    { label: 'Transcription', value: 'Transcription', count: tasks.filter((t) => t.category.toLowerCase() === 'transcription').length },
    { label: 'Data Annotation', value: 'Data Annotation', count: tasks.filter((t) => t.category.toLowerCase() === 'data annotation').length },
  ];

  const subtypes = useMemo(() => {
    if (activeCategory === 'all') return [];
    const set = new Set<string>();
    tasks.forEach((t) => {
      if (t.category.toLowerCase() === activeCategory.toLowerCase()) {
        set.add(t.subtype);
      }
    });
    return Array.from(set);
  }, [tasks, activeCategory]);

  const filteredTasks = useMemo(() => {
    let result = [...tasks];

    // Category filter
    if (activeCategory !== 'all') {
      result = result.filter((t) => t.category.toLowerCase() === activeCategory.toLowerCase());
    }

    // Subtype filter
    if (activeSubtype !== 'all') {
      result = result.filter((t) => t.subtype.toLowerCase() === activeSubtype.toLowerCase());
    }

    // Status filter
    if (statusFilter === 'available') {
      result = result.filter((t) => t.remainingSlots > 0 && t.status === 'available');
    } else if (statusFilter === 'full') {
      result = result.filter((t) => t.remainingSlots <= 0 || t.status === 'full');
    }

    // Min payment
    if (minPayment > 0) {
      result = result.filter((t) => t.payment >= minPayment);
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          t.subtype.toLowerCase().includes(q) ||
          t.clientName.toLowerCase().includes(q) ||
          t.id.toLowerCase().includes(q)
      );
    }

    // Sorting
    if (sortBy === 'highest_payment') {
      result.sort((a, b) => b.payment - a.payment);
    } else if (sortBy === 'lowest_payment') {
      result.sort((a, b) => a.payment - b.payment);
    } else if (sortBy === 'most_slots') {
      result.sort((a, b) => b.remainingSlots - a.remainingSlots);
    } else if (sortBy === 'almost_full') {
      result.sort((a, b) => {
        if (a.remainingSlots === 0) return 1;
        if (b.remainingSlots === 0) return -1;
        return a.remainingSlots - b.remainingSlots;
      });
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.clientRating - a.clientRating);
    } else {
      // Default: newest
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return result;
  }, [tasks, activeCategory, activeSubtype, statusFilter, minPayment, searchQuery, sortBy]);

  // Total pages
  const totalPages = Math.max(1, Math.ceil(filteredTasks.length / itemsPerPage));
  const validCurrentPage = Math.min(Math.max(1, currentPage), totalPages);

  const paginatedTasks = useMemo(() => {
    const startIndex = (validCurrentPage - 1) * itemsPerPage;
    return filteredTasks.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredTasks, validCurrentPage, itemsPerPage]);

  const startIndex = (validCurrentPage - 1) * itemsPerPage + 1;
  const endIndex = Math.min(validCurrentPage * itemsPerPage, filteredTasks.length);

  const handleJumpPage = (e: React.FormEvent) => {
    e.preventDefault();
    const pageNum = parseInt(jumpPageInput, 10);
    if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= totalPages) {
      setCurrentPage(pageNum);
      setJumpPageInput('');
      window.scrollTo({ top: 120, behavior: 'smooth' });
    }
  };

  const handlePageChange = (page: number) => {
    const clamped = Math.min(Math.max(1, page), totalPages);
    setCurrentPage(clamped);
    window.scrollTo({ top: 120, behavior: 'smooth' });
  };

  // Generate pagination numbers
  const getPageNumbers = () => {
    const delta = 2;
    const range: (number | string)[] = [];
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= validCurrentPage - delta && i <= validCurrentPage + delta)) {
        range.push(i);
      } else if (range[range.length - 1] !== '...') {
        range.push('...');
      }
    }
    return range;
  };

  const totalCatalogCount = tasks.length || stats.totalTasks;

  return (
    <div id="tasks-explorer" className="py-8 sm:py-12 bg-neutral-50 dark:bg-neutral-950 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Header Title with Dynamic Live Database Stats */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 dark:text-white tracking-tight">
                Explore Writing Jobs & Micro-Tasks
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-800 dark:bg-orange-950/80 dark:text-orange-300">
                {totalCatalogCount.toLocaleString('id-ID')} Total
              </span>
            </div>
            <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
              Menampilkan{' '}
              <span className="font-bold text-neutral-800 dark:text-neutral-200">
                {filteredTasks.length > 0 ? `${startIndex}–${endIndex}` : '0'}
              </span>{' '}
              dari{' '}
              <span className="font-bold text-neutral-800 dark:text-neutral-200">
                {filteredTasks.length.toLocaleString('id-ID')}
              </span>{' '}
              tugas tersaring (Katalog aktif: {totalCatalogCount.toLocaleString('id-ID')} pekerjaan terdaftar).
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {onRefreshTasks && (
              <button
                type="button"
                onClick={onRefreshTasks}
                className="p-2.5 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-300 hover:text-orange-500 transition-colors shadow-xs cursor-pointer"
                title="Refresh Task Database"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            )}

            {/* Quick Status Segmented Switch */}
            <div className="inline-flex p-1 rounded-xl bg-neutral-200/80 dark:bg-neutral-800 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setStatusFilter('available')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  statusFilter === 'available'
                    ? 'bg-white dark:bg-neutral-900 text-orange-600 dark:text-orange-400 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                Available ({stats.availableTasks})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  statusFilter === 'all'
                    ? 'bg-white dark:bg-neutral-900 text-orange-600 dark:text-orange-400 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                All ({totalCatalogCount})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('full')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  statusFilter === 'full'
                    ? 'bg-white dark:bg-neutral-900 text-orange-600 dark:text-orange-400 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                Full ({stats.fullTasks})
              </button>
            </div>
          </div>
        </div>

        {/* Search & Filter Controls Bar */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-xs space-y-4">
          <div className="flex flex-col md:flex-row gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari tugas berdasarkan judul, topik, klien, ID (#task-100), atau format..."
                className="w-full pl-10 pr-10 py-2.5 text-xs sm:text-sm rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/60 text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Sort & Filter Dropdowns */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3.5" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="pl-9 pr-8 py-2.5 text-xs font-semibold rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/60 text-neutral-800 dark:text-neutral-200 focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
                >
                  <option value="newest">Urutkan: Terbaru</option>
                  <option value="highest_payment">Bayaran Tertinggi ($)</option>
                  <option value="lowest_payment">Bayaran Terendah ($)</option>
                  <option value="most_slots">Slot Terbanyak</option>
                  <option value="almost_full">Hampir Penuh</option>
                  <option value="rating">Rating Klien Tertinggi</option>
                </select>
              </div>

              {/* Min Payment Filter */}
              <div className="flex items-center gap-1.5 text-xs text-neutral-500">
                <span className="font-semibold text-neutral-700 dark:text-neutral-300">Min $:</span>
                <select
                  value={minPayment}
                  onChange={(e) => setMinPayment(Number(e.target.value))}
                  className="px-3 py-2.5 text-xs font-semibold rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/60 text-neutral-800 dark:text-neutral-200 focus:outline-none cursor-pointer"
                >
                  <option value="0">Semua</option>
                  <option value="5">$5.00+</option>
                  <option value="10">$10.00+</option>
                  <option value="20">$20.00+</option>
                  <option value="40">$40.00+</option>
                </select>
              </div>

              {/* Items Per Page Selector */}
              <div className="flex items-center gap-1.5 text-xs text-neutral-500">
                <span className="font-semibold text-neutral-700 dark:text-neutral-300">Tampil:</span>
                <select
                  value={itemsPerPage}
                  onChange={(e) => {
                    setItemsPerPage(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="px-2.5 py-2.5 text-xs font-semibold rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/60 text-neutral-800 dark:text-neutral-200 focus:outline-none cursor-pointer"
                >
                  <option value="24">24 / hal</option>
                  <option value="48">48 / hal</option>
                  <option value="96">96 / hal</option>
                  <option value="120">120 / hal</option>
                </select>
              </div>
            </div>
          </div>

          {/* Category Tabs (All 7 Categories) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.value}
                type="button"
                onClick={() => {
                  setActiveCategory(cat.value);
                  setActiveSubtype('all');
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeCategory.toLowerCase() === cat.value.toLowerCase()
                    ? 'bg-orange-500 text-white shadow-xs'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-700'
                }`}
              >
                <span>{cat.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    activeCategory.toLowerCase() === cat.value.toLowerCase()
                      ? 'bg-orange-600 text-white'
                      : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            ))}
          </div>

          {/* Subtypes Pills (if specific category selected) */}
          {subtypes.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap pt-2 border-t border-neutral-100 dark:border-neutral-800 text-[11px]">
              <span className="font-semibold text-neutral-400 mr-1">Spesialisasi:</span>
              <button
                type="button"
                onClick={() => setActiveSubtype('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                  activeSubtype === 'all'
                    ? 'bg-neutral-800 text-white dark:bg-neutral-200 dark:text-neutral-900 font-bold'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200'
                }`}
              >
                Semua {activeCategory}
              </button>
              {subtypes.map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setActiveSubtype(st)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                    activeSubtype.toLowerCase() === st.toLowerCase()
                      ? 'bg-neutral-800 text-white dark:bg-neutral-200 dark:text-neutral-900 font-bold'
                      : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Top Pagination Summary Bar */}
        {filteredTasks.length > 0 && (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-2 text-xs text-neutral-500">
            <div>
              Halaman <span className="font-bold text-neutral-900 dark:text-white">{validCurrentPage}</span> dari{' '}
              <span className="font-bold text-neutral-900 dark:text-white">{totalPages}</span> (Menampilkan{' '}
              <span className="font-bold">{startIndex}–{endIndex}</span> dari {filteredTasks.length.toLocaleString('id-ID')} tugas)
            </div>

            <div className="flex items-center gap-2">
              <form onSubmit={handleJumpPage} className="flex items-center gap-1.5">
                <span className="text-[11px]">Ke hal:</span>
                <input
                  type="number"
                  min="1"
                  max={totalPages}
                  value={jumpPageInput}
                  onChange={(e) => setJumpPageInput(e.target.value)}
                  placeholder={validCurrentPage.toString()}
                  className="w-14 px-2 py-1 text-center text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1 text-xs font-bold rounded-lg bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 hover:bg-orange-500 hover:text-white cursor-pointer transition-colors"
                >
                  Go
                </button>
              </form>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={validCurrentPage <= 1}
                  onClick={() => handlePageChange(validCurrentPage - 1)}
                  className="p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 disabled:opacity-30 cursor-pointer"
                  title="Halaman Sebelumnya"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={validCurrentPage >= totalPages}
                  onClick={() => handlePageChange(validCurrentPage + 1)}
                  className="p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 disabled:opacity-30 cursor-pointer"
                  title="Halaman Berikutnya"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Task Cards Grid */}
        {filteredTasks.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-3">
            <BookOpen className="w-12 h-12 text-neutral-400 mx-auto" />
            <h3 className="text-base font-bold text-neutral-900 dark:text-white">
              Tidak Ada Tugas yang Cocok dengan Filter Saat Ini
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-sm mx-auto">
              Coba sesuaikan kata kunci pencarian, ubah kategori, atau reset filter untuk melihat semua {totalCatalogCount.toLocaleString('id-ID')} pekerjaan yang tersedia.
            </p>
            <button
              type="button"
              onClick={() => {
                setActiveCategory('all');
                setActiveSubtype('all');
                setStatusFilter('available');
                setSearchQuery('');
                setMinPayment(0);
              }}
              className="mt-2 px-4 py-2 text-xs font-bold rounded-xl bg-orange-500 text-white cursor-pointer hover:bg-orange-600 transition-colors"
            >
              Reset Semua Filter
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {paginatedTasks.map((task) => {
              const isFull = task.remainingSlots <= 0 || task.status === 'full';
              return (
                <div
                  key={task.id}
                  id={`task-card-${task.id}`}
                  onClick={() => setSelectedTask(task)}
                  className="p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:border-orange-500/60 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    {/* Category & Payment Header */}
                    <div className="flex items-center justify-between gap-2 mb-2.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 uppercase">
                          {task.category}
                        </span>
                        <span className="text-[10px] font-mono text-neutral-400">
                          #{task.id.replace('task-', 'TID-')}
                        </span>
                      </div>
                      <span className="text-base font-black text-emerald-600 dark:text-emerald-400 shrink-0">
                        ${task.payment.toFixed(2)} USD
                      </span>
                    </div>

                    {/* Task Title */}
                    <h3 className="text-sm font-bold text-neutral-900 dark:text-white line-clamp-2 group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors leading-snug">
                      {task.title}
                    </h3>

                    {/* Subtype and Scope metadata */}
                    <div className="flex items-center gap-2 mt-1.5 text-[11px] text-neutral-500 dark:text-neutral-400">
                      <span className="font-medium text-orange-600 dark:text-orange-400">{task.subtype}</span>
                      <span>•</span>
                      <span>{task.wordCount}</span>
                    </div>

                    {/* Description preview */}
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-2 line-clamp-2 leading-relaxed">
                      {task.description}
                    </p>
                  </div>

                  {/* Footer metadata & Action Button */}
                  <div className="mt-4 pt-3.5 border-t border-neutral-100 dark:border-neutral-800 space-y-2.5">
                    <div className="flex items-center justify-between text-[11px] text-neutral-500 dark:text-neutral-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-neutral-400" /> {task.estimatedTime}
                      </span>
                      <span className="flex items-center gap-1">
                        <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />{' '}
                        {task.clientRating.toFixed(1)}
                      </span>
                      <span
                        className={`font-bold ${
                          isFull
                            ? 'text-rose-600 dark:text-rose-400'
                            : task.remainingSlots <= 5
                            ? 'text-amber-600 dark:text-amber-400'
                            : 'text-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        {isFull ? 'FULL' : `${task.remainingSlots} slot tersisa`}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        className="w-full py-2 text-xs font-bold rounded-xl bg-neutral-100 hover:bg-orange-500 hover:text-white dark:bg-neutral-800 dark:hover:bg-orange-600 text-neutral-800 dark:text-neutral-200 transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <span>Lihat Detail Tugas</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Bottom Comprehensive Pagination Bar */}
        {filteredTasks.length > 0 && totalPages > 1 && (
          <div className="pt-6 pb-4 border-t border-neutral-200 dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-neutral-500 dark:text-neutral-400">
              Menampilkan Halaman <span className="font-bold text-neutral-900 dark:text-white">{validCurrentPage}</span> dari{' '}
              <span className="font-bold text-neutral-900 dark:text-white">{totalPages}</span> ({filteredTasks.length.toLocaleString('id-ID')} Total Tugas)
            </div>

            <div className="flex items-center gap-1 flex-wrap justify-center">
              <button
                type="button"
                disabled={validCurrentPage <= 1}
                onClick={() => handlePageChange(1)}
                className="px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 disabled:opacity-30 cursor-pointer flex items-center gap-1"
                title="Halaman Pertama"
              >
                <ChevronsLeft className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Awal</span>
              </button>

              <button
                type="button"
                disabled={validCurrentPage <= 1}
                onClick={() => handlePageChange(validCurrentPage - 1)}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 disabled:opacity-30 cursor-pointer flex items-center gap-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Prev</span>
              </button>

              {getPageNumbers().map((num, idx) => {
                if (num === '...') {
                  return (
                    <span key={`ellipsis-${idx}`} className="px-2 py-1 text-xs text-neutral-400">
                      ...
                    </span>
                  );
                }
                const isSelected = num === validCurrentPage;
                return (
                  <button
                    key={`page-${num}`}
                    type="button"
                    onClick={() => handlePageChange(num as number)}
                    className={`min-w-[32px] px-2.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-orange-500 text-white shadow-xs'
                        : 'border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                    }`}
                  >
                    {num}
                  </button>
                );
              })}

              <button
                type="button"
                disabled={validCurrentPage >= totalPages}
                onClick={() => handlePageChange(validCurrentPage + 1)}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 disabled:opacity-30 cursor-pointer flex items-center gap-1"
              >
                <span>Next</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                disabled={validCurrentPage >= totalPages}
                onClick={() => handlePageChange(totalPages)}
                className="px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-300 disabled:opacity-30 cursor-pointer flex items-center gap-1"
                title="Halaman Terakhir"
              >
                <span className="hidden sm:inline">Akhir</span>
                <ChevronsRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailPage
          task={selectedTask}
          user={user}
          onClose={() => setSelectedTask(null)}
          onClaimTask={async (id) => {
            const res = await onClaimTask(id);
            if (res) {
              // decrement local state for instant responsiveness
              selectedTask.remainingSlots = Math.max(0, selectedTask.remainingSlots - 1);
              if (selectedTask.remainingSlots === 0) selectedTask.status = 'full';
            }
            return res;
          }}
          onOpenLogin={onOpenLogin}
        />
      )}
    </div>
  );
};
