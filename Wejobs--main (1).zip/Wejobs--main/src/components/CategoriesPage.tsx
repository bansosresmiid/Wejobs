import React from 'react';
import {
  Edit3,
  Feather,
  FileCheck,
  BookOpen,
  Languages,
  Headphones,
  Tag,
  ChevronRight,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface CategoriesPageProps {
  onNavigate: (route: string) => void;
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({ onNavigate }) => {
  const disciplines = [
    {
      title: 'Writing',
      taskCount: 632,
      icon: <Edit3 className="w-6 h-6 text-orange-500" />,
      tagline: 'Direct copy, informative articles, press releases, newsletters, and structured blog posts.',
      paymentRange: '$4.50 – $34.90 USD',
      wordCounts: '600 – 2,500 Words',
      subtypes: [
        'Articles & Insights',
        'Blog Posts & Listicles',
        'Copywriting & Ad Headlines',
        'Product Descriptions',
        'Press Releases & Media Alerts',
        'Business Proposals & Pitches',
      ],
    },
    {
      title: 'Creative Writing',
      taskCount: 632,
      icon: <Feather className="w-6 h-6 text-amber-500" />,
      tagline: 'High fantasy prose, mystery thrillers, science fiction lore, scripts, and narrative arcs.',
      paymentRange: '$8.50 – $87.70 USD',
      wordCounts: '800 – 6,000 Words',
      subtypes: [
        'Novel Fiksi Fantasi & Sci-Fi',
        'Horor & Misteri Thriller',
        'Romantis & Drama Kontemporer',
        'Naskah Drama & Dialog Karakter',
        'Puisi, Soneta & Lirik Tematik',
        'Worldbuilding & Panduan Lore',
      ],
    },
    {
      title: 'Editing',
      taskCount: 632,
      icon: <FileCheck className="w-6 h-6 text-emerald-500" />,
      tagline: 'Meticulous proofreading, grammar corrections, tone alignment, and developmental editing.',
      paymentRange: '$3.50 – $25.90 USD',
      wordCounts: '600 – 5,000 Words',
      subtypes: [
        'Proofreading & Typo Correction',
        'Grammar, Syntax & Punctuation',
        'Structural & Developmental',
        'Fact-Checking & Source Audit',
        'Academic Formatting (APA/MLA)',
        'Tone Alignment & Brand Voice',
      ],
    },
    {
      title: 'Research & Writing',
      taskCount: 632,
      icon: <BookOpen className="w-6 h-6 text-blue-500" />,
      tagline: 'In-depth literature reviews, whitepapers, market analysis digests, and technical briefs.',
      paymentRange: '$10.00 – $88.75 USD',
      wordCounts: '1,200 – 6,000 Words',
      subtypes: [
        'Literature Reviews & Meta-Synthesis',
        'Executive Tech & Industry Summaries',
        'Comparative Market & Competitor Briefs',
        'Deep-Dive Whitepapers',
        'Clinical Trial & Medical Digests',
        'ESG, Climate & Sustainability Reports',
      ],
    },
    {
      title: 'Translation',
      taskCount: 631,
      icon: <Languages className="w-6 h-6 text-indigo-500" />,
      tagline: 'Professional localization, bilingual technical documents, subtitles, and transcreation.',
      paymentRange: '$6.50 – $48.50 USD',
      wordCounts: '600 – 4,000 Words',
      subtypes: [
        'English to Indonesian Localization',
        'Indonesian to English Translation',
        'Corporate Contract & Legal',
        'Software UI & App Strings',
        'Documentary Subtitling',
        'Marketing Campaign Transcreation',
      ],
    },
    {
      title: 'Transcription',
      taskCount: 631,
      icon: <Headphones className="w-6 h-6 text-purple-500" />,
      tagline: 'Audio/video minutes, podcast timestamping, earnings calls, and panel depositions.',
      paymentRange: '$5.50 – $37.00 USD',
      wordCounts: '20 – 60 Menit Audio/Video',
      subtypes: [
        'Audio Podcast Transcription',
        'Video Interview & Panel Minutes',
        'Investor Earnings Call Transcripts',
        'Medical & Clinical Consultation Notes',
        'Legal Deposition Audio Records',
        'Academic Keynote Lecture Minutes',
      ],
    },
    {
      title: 'Data Annotation',
      taskCount: 631,
      icon: <Tag className="w-6 h-6 text-teal-500" />,
      tagline: 'Sentiment scoring, named entity tagging (NER), dialogue quality review, and dataset cleanup.',
      paymentRange: '$2.75 – $17.05 USD',
      wordCounts: '350 – 1,200 Baris Dataset',
      subtypes: [
        'Sentiment & Customer Intent Tagging',
        'NER in Financial & Business News',
        'Content Safety & Policy Moderation',
        'Multi-turn AI Dialogue Evaluation',
        'Factuality Verification QA',
        'Semantic Search Query Relevance',
      ],
    },
  ];

  const totalCatalogTasks = disciplines.reduce((acc, d) => acc + d.taskCount, 0);

  return (
    <div id="categories-page" className="py-10 sm:py-14 bg-neutral-50 dark:bg-neutral-950 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-800 dark:bg-orange-950/60 dark:text-orange-300">
            <span>Katalog Lengkap: {totalCatalogTasks.toLocaleString('id-ID')} Tugas Aktif</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black text-neutral-900 dark:text-white tracking-tight">
            Kategori & Spesifikasi Pekerjaan
          </h1>
          <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
            Semua {totalCatalogTasks.toLocaleString('id-ID')} pekerjaan terbagi secara proporsional ke dalam 7 kategori utama dengan dana kompensasi tersimpan aman di sistem Escrow WEJOBS. Pilih kategori yang paling sesuai dengan keahlian Anda.
          </p>
        </div>

        {/* Categories Grid - Clean, lightweight and super fast */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {disciplines.map((d) => (
            <div
              key={d.title}
              className="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-xs hover:border-orange-500/60 transition-all flex flex-col justify-between group"
            >
              <div className="space-y-4">
                {/* Header Icon + Title + Count */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-neutral-100 dark:bg-neutral-800 border border-neutral-200/80 dark:border-neutral-700">
                      {d.icon}
                    </div>
                    <div>
                      <h2 className="text-base sm:text-lg font-bold text-neutral-900 dark:text-white group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">
                        {d.title}
                      </h2>
                      <span className="text-xs font-bold text-orange-600 dark:text-orange-400">
                        {d.taskCount} Pekerjaan Aktif
                      </span>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
                  {d.tagline}
                </p>

                {/* Pay & Scope Badges */}
                <div className="flex items-center justify-between text-[11px] pt-1">
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold border border-emerald-200/60 dark:border-emerald-800/60">
                    {d.paymentRange}
                  </span>
                  <span className="px-2 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-medium">
                    {d.wordCounts}
                  </span>
                </div>

                {/* Subtypes Pills */}
                <div className="space-y-1.5 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                    Spesialisasi Populer:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {d.subtypes.map((st) => (
                      <span
                        key={st}
                        onClick={() => onNavigate(`/tasks?category=${encodeURIComponent(d.title)}`)}
                        className="px-2 py-0.5 rounded text-[11px] bg-neutral-50 dark:bg-neutral-800/80 text-neutral-600 dark:text-neutral-300 hover:bg-orange-50 hover:text-orange-600 dark:hover:bg-neutral-700 cursor-pointer transition-colors"
                      >
                        {st}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-5 mt-4 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => onNavigate(`/tasks?category=${encodeURIComponent(d.title)}`)}
                  className="w-full py-2.5 px-4 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>Lihat {d.taskCount} Tugas {d.title}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner */}
        <div className="p-6 rounded-2xl bg-neutral-900 text-white flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold">Siap Mengambil Tugas?</h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Jelajahi seluruh {totalCatalogTasks.toLocaleString('id-ID')} pekerjaan di halaman Explore Jobs dan klaim slot tugas sekarang.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('/tasks')}
            className="px-5 py-2.5 rounded-xl bg-white text-neutral-950 font-bold text-xs hover:bg-neutral-100 transition-colors shrink-0 cursor-pointer"
          >
            Buka Semua 4.421 Pekerjaan
          </button>
        </div>
      </div>
    </div>
  );
};

